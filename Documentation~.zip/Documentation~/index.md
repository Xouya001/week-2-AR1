# About XR Simulation Environments

The XR Simulation Environments package sample includes a collection of indoor and outdoor Simulation environments and modular pieces to build your own.  Simulation environments are prefabs that act as substitutes for the real world in AR.  The XR Simulation Plug-in Provider, available in AR Foundation, uses Simulation environments to provide AR functionality.
